# 几个 GB/T7714相关的csl文件

[![johnmy](https://pic4.zhimg.com/da8e974dc_xs.jpg)](https://www.zhihu.com/people/johnmy-89)

[johnmy](https://www.zhihu.com/people/johnmy-89)

教师

关注

57 人赞同了该文章

1. 来自于Github（[citation-style-language/styles](https://link.zhihu.com/?target=https%3A//github.com/citation-style-language/styles/blob/5a35ce07b79e6095621b28de9d86740e139fde8a/chinese-gb7714-2015-numeric.csl)）的 GB/T 7714-2015 CSL (chinese-gb7714-2005-numeric)

链接: [https://pan.baidu.com/s/1r5JTZ9VTzlDiOi7-XNIheA](https://link.zhihu.com/?target=https%3A//pan.baidu.com/s/1r5JTZ9VTzlDiOi7-XNIheA) 提取码: ymym

生成文献格式：

```text
[1]  XU Y, ZHAO X, BIAN G, 等. Structural and solubility properties of pale, soft and exudative (PSE)-like chicken breast myofibrillar protein: Effect of glycosylation[J]. LWT-Food Science and Technology, 2018,95:209–215. 
[2]  GUO J, ZHOU Y, YANG K, 等. Effect of low-frequency magnetic field on the gel properties of pork myofibrillar proteins[J]. Food Chemistry, 2019,274:775–781. 
[3]  韩敏义, 费英, 徐幸莲, 等. 低场NMR研究pH对肌原纤维蛋白热诱导凝胶的影响[J]. 中国农业科学, 2009,42(06):2098–2104. 
```

\2. 根据1修改的GB/T 7714-2015 CSL：卷和页码前加了空格。

链接: [https://pan.baidu.com/s/19OOaObdjLz_NfppyYPYASw](https://link.zhihu.com/?target=https%3A//pan.baidu.com/s/19OOaObdjLz_NfppyYPYASw) 提取码: xf9n

生成文献格式：

```text
[1]  XU Y, ZHAO X, BIAN G, 等. Structural and solubility properties of pale, soft and exudative (PSE)-like chicken breast myofibrillar protein: Effect of glycosylation[J]. LWT-Food Science and Technology, 2018, 95: 209–215. 
[2]  GUO J, ZHOU Y, YANG K, 等. Effect of low-frequency magnetic field on the gel properties of pork myofibrillar proteins[J]. Food Chemistry, 2019, 274: 775–781. 
[3]  韩敏义, 费英, 徐幸莲, 等. 低场NMR研究pH对肌原纤维蛋白热诱导凝胶的影响[J]. 中国农业科学, 2009, 42(06): 2098–2104. 
```

\3. 根据2 进一步修改的，仅作者的首字母大写。

链接: [https://pan.baidu.com/s/14hDEU9wZYzH_wEF3k_ft-Q](https://link.zhihu.com/?target=https%3A//pan.baidu.com/s/14hDEU9wZYzH_wEF3k_ft-Q) 提取码: xjs9

生成文献格式：

```text
[1]  Xu Y, Zhao X, Bian G, 等. Structural and solubility properties of pale, soft and exudative (PSE)-like chicken breast myofibrillar protein: Effect of glycosylation[J]. LWT-Food Science and Technology, 2018, 95: 209–215. 
[2]  Guo J, Zhou Y, Yang K, 等. Effect of low-frequency magnetic field on the gel properties of pork myofibrillar proteins[J]. Food Chemistry, 2019, 274: 775–781. 
[3]  韩敏义, 费英, 徐幸莲, 等. 低场NMR研究pH对肌原纤维蛋白热诱导凝胶的影响[J]. 中国农业科学, 2009, 42(06): 2098–2104. 
```

\4. GB/T 7714-2005 CSL（

[https://www.zotero.org/styles/chinese-gb7714-2005-numeric](https://link.zhihu.com/?target=https%3A//www.zotero.org/styles/chinese-gb7714-2005-numeric)

）的修改版，仅作者的首字母大写。

链接: [https://pan.baidu.com/s/1VYkf0U0udi-73nP7TgO3fA](https://link.zhihu.com/?target=https%3A//pan.baidu.com/s/1VYkf0U0udi-73nP7TgO3fA) 提取码: d4s5

生成文献格式：

```text
[1] Xu Y, Zhao X, Bian G, 等. Structural and solubility properties of pale, soft and exudative (PSE)-like chicken breast myofibrillar protein: Effect of glycosylation[J]. LWT-Food Science and Technology, 2018, 95: 209–215.
[2] Guo J, Zhou Y, Yang K, 等. Effect of low-frequency magnetic field on the gel properties of pork myofibrillar proteins[J]. Food Chemistry, 2019, 274: 775–781.
[3] 韩敏义, 费英, 徐幸莲, 等. 低场NMR研究pH对肌原纤维蛋白热诱导凝胶的影响[J]. 中国农业科学, 2009, 42(06): 2098–2104.
```

\5. China National Standard GB/T 7714-2015 (author-date, Chinese)修改版：仅作者的首字母大写（原来为作者所有字母大写），源于知友 

[@Daisy要努力毕业](https://www.zhihu.com/people/3a3e38c3595576803b233c3fc7972092)

 修改，谢谢提供。



链接: [https://pan.baidu.com/s/1R8EJPIk88Z8islKJoz__YA](https://link.zhihu.com/?target=https%3A//pan.baidu.com/s/1R8EJPIk88Z8islKJoz__YA) 提取码: e4wc

生成文献格式：

```text
Han Y-X, Cheng J-H, Sun D-W, 2019. Changes in Activity, Structure and Morphology of Horseradish Peroxidase Induced by Cold Plasma[J]. Food Chemistry, : 125240. DOI:10.1016/j.foodchem.2019.125240.
Li C, He L, Ma S, et al., 2018. Effect of Irradiation Modification on Conformation and Gelation Properties of Pork Myofibrillar and Sarcoplasmic Protein[J]. Food Hydrocolloids, 84: 181–192. DOI:10.1016/j.foodhyd.2018.05.047.
Suman S P, Mancini R A, Joseph P, et al., 2010. Packaging-Specific Influence of Chitosan on Color Stability and Lipid Oxidation in Refrigerated Ground Beef[J]. Meat Science, 86(4): 994–998.
```

6.China National Standard GB/T 7714-2015 (author-date, Chinese)修改版：显示所有作者，仅作者的首字母大写。

链接: [https://pan.baidu.com/s/1G0DgIPFD1NW5_eLuHyUfdg](https://link.zhihu.com/?target=https%3A//pan.baidu.com/s/1G0DgIPFD1NW5_eLuHyUfdg) 提取码: m6kq

生成文献格式：

```text
[1] 	Chizoba Ekezie F-G, Sun D-W, Cheng J-H. A review on recent advances in cold plasma technology for the food industry: Current applications and future trends[J]. Trends in Food Science & Technology, 2017, 69: 46–58. 
[2] 	Ulbin-Figlewicz N, Jarmoluk A, Marycz K. Antimicrobial activity of low-pressure plasma treatment against selected foodborne bacteria and meat microbiota[J]. Annals of Microbiology, 2015, 65(3): 1537–1546. 
[3] 	康超娣, 相启森, 刘骁, 栗俊广, 张华, 白艳红. 等离子体活化水在食品工业中应用研究进展[J]. 食品工业科技, 2018, 39(07): 348–352. 
[4] 	李帅, 梁珊, 谷雨. 辉光放电低温等离子体改性大豆分离蛋白可食膜工艺优化[J]. 农业工程学报, 2018, 34(14): 280–287. 
```

\7. china-national-standard-gb-t-7714-2015-numeric_BiLan.csl：中文作者超过3个显示为“等”，英文显示为“et al”，作者大写，来源于网友牛耕田，感谢。下载地址：链接: [https://pan.baidu.com/s/10ZlUoPOfO6ZtfvoRMlrW7A](https://link.zhihu.com/?target=https%3A//pan.baidu.com/s/10ZlUoPOfO6ZtfvoRMlrW7A) 提取码: f6zy

生成文献格式：

```text
[1] 唐霄, 孙杨赢, 江雪婷, 等. 不同蛋白酶制备鹅肉呈味肽的对比分析[J]. 食品科学, 2019, 40(22): 141–146.
[2] DONG M, TIAN H, XU Y, et al. Effects of pulsed electric fields on the conformation and gelation properties of myofibrillar proteins isolated from pale, soft, exudative (PSE)-like chicken breast meat: A molecular dynamics Study[J]. Food Chemistry, 2020: 128306. DOI:10.1016/j.foodchem.2020.128306.
[3] WU L, ZHAO W, YANG R, et al. Aggregation of egg white proteins with pulsed electric fields and thermal Processes: 10[J]. Journal of the Science of Food and Agriculture, 2016, 96(10): 3334–3341. DOI:10.1002/jsfa.7512.
[4] 侯钰柯, 石金明, 曾宪明, 等. 类蛋白反应及其在肉类中的应用[J]. 食品与发酵工业, 2020: 1–9.
```

\8. china-national-standard-gb-t-7714-2015-numeric-aulower-bilan.csl：7的修改版，作者改为小写。下载地址：链接: [https://pan.baidu.com/s/1wn9P_4gJMva3AAUZwrHT4Q](https://link.zhihu.com/?target=https%3A//pan.baidu.com/s/1wn9P_4gJMva3AAUZwrHT4Q) 提取码: dt2j

```text
[1] 唐霄, 孙杨赢, 江雪婷, 等. 不同蛋白酶制备鹅肉呈味肽的对比分析[J]. 食品科学, 2019, 40(22): 141–146.
[2] Dong M, Tian H, Xu Y, et al. Effects of pulsed electric fields on the conformation and gelation properties of myofibrillar proteins isolated from pale, soft, exudative (PSE)-like chicken breast meat: A molecular dynamics Study[J]. Food Chemistry, 2020: 128306. DOI:10.1016/j.foodchem.2020.128306.
[3] Wu L, Zhao W, Yang R, et al. Aggregation of egg white proteins with pulsed electric fields and thermal Processes: 10[J]. Journal of the Science of Food and Agriculture, 2016, 96(10): 3334–3341. DOI:10.1002/jsfa.7512.
[4] 侯钰柯, 石金明, 曾宪明, 等. 类蛋白反应及其在肉类中的应用[J]. 食品与发酵工业, 2020: 1–9.
```

9.wjq.csl: 7的修改版，文献题目大小写保持和Zotero中一致。下载地址：链接: [https://pan.baidu.com/s/1mqdB46I7GBA0mfyoW8bTig](https://link.zhihu.com/?target=https%3A//pan.baidu.com/s/1mqdB46I7GBA0mfyoW8bTig) 提取码: caer ，显示效果为：



```text
[1] DEBNATH S, QIN J, BAHRANI B, et al. Operation, control, and applications of the modular multilevel converter: A review[J]. IEEE Transactions on Power Electronics, 2015, 30(1): 37–53. DOI:10.1109/TPEL.2014.2309937.
[2] 韦延方, 卫志农, 孙国强, 等. 一种新型的高压直流输电技术——MMC-HVDC[J]. 电力自动化设备, 2012, 32(07): 1–9.
[3] 陈海荣, 徐政. 基于同步坐标变换的VSC-HVDC暂态模型及其控制器[J]. 电工技术学报, 2007(02): 121–126.
[4]ILVES K, ANTONOPOULOS A, NORRGA S, et al. A new modulation method for the modular multilevel converter allowing fundamental switching frequency[C]//8th International Conference on Power Electronics - ECCE Asia. . DOI:10.1109/ICPE.2011.5944672.
```

\10. china-national-standard-gb-t-7714-2015-note-revised.csl 脚注型的style修改版。重复引用的不是同上，而是重复显示，如下面显示的1和4

链接: [https://pan.baidu.com/s/1o2N8kd7dMSny77VcGl-YRw](https://link.zhihu.com/?target=https%3A//pan.baidu.com/s/1o2N8kd7dMSny77VcGl-YRw) 提取码: 971j

```text
  1 徐鑫, 韩敏义, 郭振, 等. 辣蓼提取物对冷却肉的保鲜效果[J]. 通化师范学院学报, 2018, 39(06): 19–24.
  2 徐渊, 韩敏义, 陈艳萍, 等. 三个品种白切鸡食用品质评价[J]. 食品工业科技, 2020: 1–12.
  3 侯钰柯, 石金明, 曾宪明, 等. 类蛋白反应及其在肉类中的应用[J]. 食品与发酵工业, 2020: 1–9.
  4 徐鑫, 韩敏义, 郭振, 等. 辣蓼提取物对冷却肉的保鲜效果[J]. 通化师范学院学报, 2018, 39(06): 19–24.
```

\11. jm-chinese-std-gb-t-7714-2005-revised.csl，jm-chinese-std-gb-t-7714-2005.csl的修改版，删除了页码冒号前面的空格，无卷时年代后面直接括号期形式，链接: [https://pan.baidu.com/s/1FHI3XJf77tYmqQ2NdYhF-g](https://link.zhihu.com/?target=https%3A//pan.baidu.com/s/1FHI3XJf77tYmqQ2NdYhF-g) 提取码: j93v

显示效果：

```text
[1] ZHANG B, QI X, MAO J, et al. Trehalose and alginate oligosaccharides affect the stability of myosin in whiteleg shrimp (Litopenaeus vannamei): The water-replacement mechanism confirmed by molecular dynamic simulation [J]. LWT - Food Science and Technology, 2020, 127: 109393.
[2] 张馨月, 邓绍林, 胡洋健, 等. 几种新型解冻技术对肉品质影响的研究进展[J]. 食品与发酵工业, 2020, 46(12): 293–298.
[3] 王建冬, 童楠楠. 数字经济背景下数据与其他生产要素的协同联动机制研究[J]. 电子政务, 2020(03): 22–31.
[4] ZHAO X, CHEN X, HAN M, et al. Application of isoelectric solubilization/precipitation processing to improve gelation properties of protein isolated from pale, soft, exudative (PSE)-like chicken breast meat [J]. LWT - Food Science and Technology, 2016, 72: 141–148.
```

要解决英文作者后面是“等”的问题参见：

[johnmy：[Zotero\]使用JurisM Style实现同时生成“et al”和“等”](https://zhuanlan.zhihu.com/p/317108621)

[johnmy：[Zotero修改版\]终于可以原生支持同时生成“et al”和“等”了](https://zhuanlan.zhihu.com/p/314928204)

[johnmy：[Zotero\]基于GB/T-7714-2015的Style实现同时生成“et al”和“等”](https://zhuanlan.zhihu.com/p/320253145)

[[Zotero+Word\]Zotero+Word2016参考文献中英文混排，解决et al和等的问题](https://zhuanlan.zhihu.com/p/58237038)