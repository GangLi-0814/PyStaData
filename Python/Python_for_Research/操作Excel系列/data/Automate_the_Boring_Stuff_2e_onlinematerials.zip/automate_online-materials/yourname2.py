while True:
    print('Please enter your name.')
    name = input()
    if name == 'your name':
        break
print('Thank you!')
