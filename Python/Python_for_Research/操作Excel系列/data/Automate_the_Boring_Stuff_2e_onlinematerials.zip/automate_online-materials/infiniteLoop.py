# Warning: You'll need to press Ctrl+C to stop this program.
while True:
    print('Hello, world!')
